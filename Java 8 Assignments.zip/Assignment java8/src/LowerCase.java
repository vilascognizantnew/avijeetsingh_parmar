import java.util.*;
 public class LowerCase {
     public static void main(String[] args){	
     Scanner in = new Scanner(System.in);
     System.out.print("Enter a String: ");
	 String line = in.nextLine();
	 line = line.toLowerCase();
	 System.out.println(line); 
	 }			
}