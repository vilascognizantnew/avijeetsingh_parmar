import java.util.Scanner;

public class LengthOfString {

	public static void main(String[] args) {
		
		String s;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter THe String");
		
		s=sc.next();
		int leng=s.length();
		
		System.out.println("The length of the String is:" + " " + leng);
		
				
		

	}

}