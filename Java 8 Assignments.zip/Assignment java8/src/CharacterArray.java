import java.util.Scanner;

public class CharacterArray {

	public static void main(String[] args) {
		
		String s ;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter The String");
		s=sc.nextLine();
		char[] arr = s.toCharArray();
		
		System.out.println(arr);
		
				
		

	}

}